$('.love').all();
